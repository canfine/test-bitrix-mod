<?
$MESS["IBLOCK_ADD_LEVEL_LAST_ERROR"] = "Дозволено додавання лише до розділів останнього рівня";
$MESS["IBLOCK_ADD_ELEMENT_NOT_FOUND"] = "Елемент не знайдено";
$MESS["IBLOCK_USER_MESSAGE_ADD_DEFAULT"] = "Елемент успішно доданий";
$MESS["IBLOCK_USER_MESSAGE_EDIT_DEFAULT"] = "Змінення успішно збережені";
$MESS["IBLOCK_FORM_WRONG_CAPTCHA"] = "Невірно введено слово з картинки";
$MESS["IBLOCK_ADD_ACCESS_DENIED"] = "Немає доступу";
$MESS["IBLOCK_ADD_MAX_ENTRIES_EXCEEDED"] = "Перевищено максимальну кількість записів";
$MESS["IBLOCK_ADD_MAX_LEVELS_EXCEEDED"] = "Перевищено максимальну кількість розділів — #MAX_LEVELS#";
$MESS["IBLOCK_ADD_ERROR_REQUIRED"] = "Поле '#PROPERTY_NAME#' має бути заповнено!";
$MESS["IBLOCK_ERROR_FILE_TOO_LARGE"] = "Розмір завантаженого файла перевищує припустиме значення";
$MESS["CC_BIEAF_ACCESS_DENIED_STATUS"] = "У вас немає прав на редагування цього запису в його поточному статусі";
$MESS["CC_BIEAF_IBLOCK_MODULE_NOT_INSTALLED"] = "Модуль Інформаційних блоків не встановлений";
?>