<?
$MESS ['IBLOCK_ELEMENT_ADD_FORM_NAME'] = "Форма обратной связи";
$MESS ['IBLOCK_ELEMENT_ADD_FORM_DESCRIPTION'] = "Форма обратной связи";
$MESS ['T_IBLOCK_DESC_ELEMENT_ADD'] = "Добавление связи";
?>