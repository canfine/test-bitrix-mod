<?
$MESS["IBLOCK_FORM_SUBMIT"] = "Speichern";
$MESS["IBLOCK_FORM_APPLY"] = "Anwenden";
$MESS["IBLOCK_FORM_RESET"] = "Zurücksetzen";
$MESS["IBLOCK_FORM_BACK"] = "Zurück zur Liste";
$MESS["IBLOCK_FORM_DATE_FORMAT"] = "Format:";
$MESS["IBLOCK_FORM_FILE_NAME"] = "Datei";
$MESS["IBLOCK_FORM_FILE_SIZE"] = "Größe";
$MESS["IBLOCK_FORM_FILE_DOWNLOAD"] = "download";
$MESS["IBLOCK_FORM_FILE_DELETE"] = "Datei löschen";
$MESS["IBLOCK_FORM_CAPTCHA_TITLE"] = "Schutz vor automatischen Einträgen";
$MESS["IBLOCK_FORM_CAPTCHA_PROMPT"] = "Geben Sie das Wort vom Bild ein";
$MESS["CT_BIEAF_PROPERTY_VALUE_NA"] = "(nicht festgelegt)";
$MESS["IBLOCK_FORM_CANCEL"] = "Abbrechen";
?>