<?
$MESS["FIELD_SEND_SUCCESS"] = "Спасибо, Ваше сообщение принято";
?>