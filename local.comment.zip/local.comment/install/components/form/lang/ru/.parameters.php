<?
$MESS["IBLOCK_FIELDS"] = "Свойства инфоблока";
$MESS["IBLOCK_TYPE"] = "Тип инфоблока";
$MESS["IBLOCK_IBLOCK"] = "Инфоблок";
$MESS["IBLOCK_PROPERTY"] = "Свойства, выводимые в форме";
$MESS["SEND_TO_MAIL"] = "Почта получателя";
$MESS["SEND_FROM_MAIL"] = "Почта отправителя";
$MESS["OK_TEXT"] = "Сообщение о успешной отправке";
$MESS["USE_AJAX"] = "Использовать режим AJAX";
$MESS["IBLOCK_USE_CAPTCHA"] = "Использовать Google  капчу? (пока не работает)";
?>