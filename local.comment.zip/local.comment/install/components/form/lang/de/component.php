<?
$MESS["IBLOCK_ADD_ERROR_REQUIRED"] = "Das Feld '#PROPERTY_NAME#' muss ausgefüllt werden!";
$MESS["IBLOCK_ADD_ELEMENT_NOT_FOUND"] = "Element wurde nicht gefunden";
$MESS["IBLOCK_ADD_ACCESS_DENIED"] = "Kein Zugriff";
$MESS["IBLOCK_FORM_WRONG_CAPTCHA"] = "Die Symbole vom Bild wurden falsch eingegeben";
$MESS["IBLOCK_ADD_MAX_ENTRIES_EXCEEDED"] = "Die maximale Anzahl der Einträge wurde überschritten";
$MESS["IBLOCK_ADD_MAX_LEVELS_EXCEEDED"] = "Die maximale Anzahl der Bereiche wurde überschritten - #MAX_LEVELS#";
$MESS["IBLOCK_ADD_LEVEL_LAST_ERROR"] = "Es ist nur das Hinzufügen in die Bereiche der letzten Ebenen erlaubt";
$MESS["IBLOCK_USER_MESSAGE_ADD_DEFAULT"] = "Das Element wurde erfolgreich hinzufgefügt";
$MESS["IBLOCK_USER_MESSAGE_EDIT_DEFAULT"] = "Änderungen wurden erfolgreich gespeichert";
$MESS["IBLOCK_ERROR_FILE_TOO_LARGE"] = "Größe der hochzuladenden Datei überschreitet den zulässigen Wert";
$MESS["CC_BIEAF_ACCESS_DENIED_STATUS"] = "Sie haben nicht genügend Rechte, um diesen Eintrag im aktuellen Status zu bearbeiten";
$MESS["CC_BIEAF_IBLOCK_MODULE_NOT_INSTALLED"] = "Das Modul \"Informationsblöcke\" wurde nicht installiert";
?>