<?php
$MESS['MAIN_BLOCK_TEAM_CLASS_IBLOCK_MODULE_NOT_INSTALLED'] = 'Модуль "Инфоблоки" не установлен';
