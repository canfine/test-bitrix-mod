<?php
$arModuleVersion = [
	'VERSION' => '0.0.1',
	'VERSION_DATE' => '2021-09-30 00:00:00',
        "MODULE_NAME" => "iblockComment",
        "MODULE_DESCRIPTION" => "Модуль комментариев к инфоблоку"
];