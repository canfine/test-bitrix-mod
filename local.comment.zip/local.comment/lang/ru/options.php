<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

$arModConf = include __DIR__ . '/../../mod_conf.php';

$MESS[$arModConf['name'] . '_TAB_SETTINGS'] = 'Настройки';
$MESS[$arModConf['name'] . '_TAB_TITLE_SETTINGS'] = 'Настройки';
$MESS[$arModConf['name'] . '_TAB_RIGHTS'] = 'Права';
$MESS[$arModConf['name'] . '_TAB_TITLE_RIGHTS'] = 'Права модуля';