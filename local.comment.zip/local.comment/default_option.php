<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

$arModConf = include __DIR__ . '/mod_conf.php';

$local_exch1c_default_option = array(
    //$arModConf['name'] . '_SOME_VAR_NAME' => "some default var value",    
);
?>
