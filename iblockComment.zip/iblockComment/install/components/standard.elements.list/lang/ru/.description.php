<?
$MESS['STANDARD_ELEMENTS_LIST_DESCRIPTION_NAME'] = 'Список элементов';
$MESS['STANDARD_ELEMENTS_LIST_DESCRIPTION_DESCRIPTION'] = 'Стандартный компонент для отображения списка элементов с постраничной навигацией';
$MESS['STANDARD_ELEMENTS_LIST_DESCRIPTION_GROUP'] = 'Системные';
$MESS['STANDARD_ELEMENTS_LIST_DESCRIPTION_DIR'] = 'Стандартные компоненты';
?>