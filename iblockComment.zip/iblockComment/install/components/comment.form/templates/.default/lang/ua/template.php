<?
$MESS["IBLOCK_FORM_CAPTCHA_PROMPT"] = "Введіть слово з картинки";
$MESS["IBLOCK_FORM_FILE_DELETE"] = "видалити файл";
$MESS["IBLOCK_FORM_APPLY"] = "Застосувати";
$MESS["IBLOCK_FORM_CAPTCHA_TITLE"] = "Захист від автоматичного заповнення";
$MESS["IBLOCK_FORM_SUBMIT"] = "Зберегти";
$MESS["IBLOCK_FORM_BACK"] = "Назад до розділу";
$MESS["IBLOCK_FORM_FILE_SIZE"] = "Розмір";
$MESS["IBLOCK_FORM_FILE_DOWNLOAD"] = "Скачати";
$MESS["IBLOCK_FORM_RESET"] = "Скинути";
$MESS["IBLOCK_FORM_FILE_NAME"] = "Файл";
$MESS["IBLOCK_FORM_DATE_FORMAT"] = "Формат: ";
$MESS["CT_BIEAF_PROPERTY_VALUE_NA"] = "(не встановлено)";
$MESS["IBLOCK_FORM_CANCEL"] = "Скасування";
?>