<?
$MESS["T_IBLOCK_DESC_ELEMENT_ADD"] = "Додавання елементів";
$MESS["IBLOCK_ELEMENT_ADD_FORM_NAME"] = "Форма додавання / редагування";
$MESS["IBLOCK_ELEMENT_ADD_FORM_DESCRIPTION"] = "Форма додавання / редагування елементу інфоблока";
?>