<?php
$arModuleVersion = [
	'VERSION' => '0.0.1',
	'VERSION_DATE' => '2017-06-19 00:00:00',
];